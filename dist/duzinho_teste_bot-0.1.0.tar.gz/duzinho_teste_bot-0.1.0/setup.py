# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['duzinho_teste_bot',
 'duzinho_teste_bot.commands',
 'duzinho_teste_bot.commands.feeds',
 'duzinho_teste_bot.database',
 'duzinho_teste_bot.responses',
 'duzinho_teste_bot.settings',
 'duzinho_teste_bot.utils',
 'duzinho_teste_bot.utils.texts']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy-Utils>=0.38.2,<0.39.0',
 'SQLAlchemy>=1.4.31,<2.0.0',
 'feedparser>=6.0.8,<7.0.0',
 'psycopg2>=2.9.3,<3.0.0',
 'python-decouple>=3.6,<4.0',
 'python-telegram-bot>=13.11,<14.0',
 'pytz>=2021.3,<2022.0']

setup_kwargs = {
    'name': 'duzinho-teste-bot',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Regy Eduardo',
    'author_email': 'regyeduardo@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.10',
}


setup(**setup_kwargs)
